import { useState, useMemo, useEffect, useCallback } from "react";

const THEMES = {
  midnight:{ name:"Midnight", bg:"#07080f", surf:"#0e1019", card:"#141520", border:"#1e2035", text:"#e8eaf6", muted:"#6b6f9a", accent:"#5b7fff", soft:"#1a2050", ok:"#22d48c", warn:"#f5a623", err:"#ff4d6d", grad:"linear-gradient(135deg,#5b7fff,#a78bfa)", tc:["#5b7fff","#22d48c","#f5a623","#ff4d6d","#a78bfa","#f472b6","#34d399","#fb923c","#38bdf8","#e879f9"] },
  arctic:  { name:"Arctic",   bg:"#f0f4f8", surf:"#ffffff", card:"#ffffff", border:"#dde3ea", text:"#1a2332", muted:"#8896a7", accent:"#0050e6", soft:"#dbeafe", ok:"#059669", warn:"#d97706", err:"#dc2626", grad:"linear-gradient(135deg,#0050e6,#0ea5e9)", tc:["#0050e6","#059669","#d97706","#dc2626","#7c3aed","#db2777","#0891b2","#65a30d","#ea580c","#9333ea"] },
  forest:  { name:"Forest",   bg:"#0a1a0c", surf:"#0f2012", card:"#142416", border:"#1f3824", text:"#d4f0d8", muted:"#6b9e72", accent:"#3dba54", soft:"#162d1a", ok:"#81c784", warn:"#ffd54f", err:"#ef9a9a", grad:"linear-gradient(135deg,#3dba54,#a5d6a7)", tc:["#3dba54","#ffb300","#ef5350","#42a5f5","#ab47bc","#26c6da","#d4e157","#ff7043","#80cbc4","#ce93d8"] },
  crimson: { name:"Crimson",  bg:"#0f0508", surf:"#1a080f", card:"#200c15", border:"#3a1220", text:"#fce4ec", muted:"#a06070", accent:"#e91e63", soft:"#4a0820", ok:"#4db6ac", warn:"#ffca28", err:"#ff5252", grad:"linear-gradient(135deg,#e91e63,#ff80ab)", tc:["#e91e63","#4db6ac","#ffca28","#ff5252","#9c27b0","#00bcd4","#8bc34a","#ff9800","#7e57c2","#26a69a"] },
  sand:    { name:"Sand",     bg:"#faf8f3", surf:"#ffffff", card:"#ffffff", border:"#e8e0d0", text:"#2c2416", muted:"#8a7a60", accent:"#c07820", soft:"#fef3d0", ok:"#2d7a4f", warn:"#b45309", err:"#b91c1c", grad:"linear-gradient(135deg,#c07820,#f0c040)", tc:["#c07820","#2d7a4f","#b45309","#b91c1c","#6d28d9","#0369a1","#166534","#92400e","#1d4ed8","#7c3aed"] },
  neon:    { name:"Neon",     bg:"#030008", surf:"#07000f", card:"#0c001a", border:"#1a0035", text:"#f0e6ff", muted:"#7a5a9a", accent:"#cc00ff", soft:"#2a0050", ok:"#00ff88", warn:"#ffcc00", err:"#ff0055", grad:"linear-gradient(135deg,#cc00ff,#00ccff)", tc:["#cc00ff","#00ff88","#ffcc00","#ff0055","#00ccff","#ff6600","#00ff44","#ff00aa","#44ff00","#0088ff"] },
  slate:   { name:"Slate",    bg:"#f8fafc", surf:"#ffffff", card:"#ffffff", border:"#e2e8f0", text:"#0f172a", muted:"#64748b", accent:"#334155", soft:"#f1f5f9", ok:"#16a34a", warn:"#ca8a04", err:"#dc2626", grad:"linear-gradient(135deg,#334155,#64748b)", tc:["#334155","#16a34a","#ca8a04","#dc2626","#7c3aed","#0891b2","#db2777","#ea580c","#0d9488","#9333ea"] },
  aurora:  { name:"Aurora",   bg:"#050d1a", surf:"#08152a", card:"#0d1f3a", border:"#162d50", text:"#e0f0ff", muted:"#5a8aaa", accent:"#00d4ff", soft:"#00344a", ok:"#00ff9d", warn:"#ffdd00", err:"#ff4455", grad:"linear-gradient(135deg,#00d4ff,#dd88ff)", tc:["#00d4ff","#00ff9d","#ffdd00","#ff4455","#dd88ff","#ff88aa","#44ffcc","#ffaa00","#00aaff","#aa44ff"] },
};

const DEFAULT_LISTS = {
  teams:     ["Tech","Design","Ops","Data","Produit","RH","Finance","Marketing","Legal"],
  depts:     ["Ingenierie","Produit","Operations","Finance","Marketing","RH","Juridique"],
  levels:    ["Junior","Mid","Senior","Manager","Directeur","VP"],
  contracts: ["CDI","CDD","Stage","Freelance","Alternance","Interim"],
  roles:     ["Dev Frontend","Dev Backend","Designer UI/UX","Chef de Projet","Product Manager","Data Engineer","DevOps","Scrum Master","Charge RH","Analyste Financier","Marketing Manager","Juriste","Ingenieur ML"],
};

const STATUSES = ["Actif","Inactif","Conge"];
const SC = { Actif:{c:"#22d48c",bg:"#22d48c18"}, Inactif:{c:"#ff4d6d",bg:"#ff4d6d18"}, Conge:{c:"#f5a623",bg:"#f5a62318"} };

const INIT_EMPS = [
  {id:1, mat:"EMP-0001",name:"Sophie Marchand",   role:"Designer UI/UX",     team:"Design",   dept:"Produit",    status:"Actif",  loc:"Paris",    level:"Senior",  contract:"CDI",   start:"2019-03-12",salary:62000,email:"s.marchand@corp.fr", phone:"+33 6 12 34 56 78"},
  {id:2, mat:"EMP-0002",name:"Lucas Fontaine",    role:"Dev Backend",         team:"Tech",     dept:"Ingenierie", status:"Actif",  loc:"Lyon",     level:"Senior",  contract:"CDI",   start:"2018-07-01",salary:68000,email:"l.fontaine@corp.fr", phone:"+33 6 23 45 67 89"},
  {id:3, mat:"EMP-0003",name:"Emma Dubois",       role:"Chef de Projet",      team:"Ops",      dept:"Operations", status:"Actif",  loc:"Paris",    level:"Manager", contract:"CDI",   start:"2017-01-15",salary:74000,email:"e.dubois@corp.fr",   phone:"+33 6 34 56 78 90"},
  {id:4, mat:"EMP-0004",name:"Nathan Petit",      role:"Dev Frontend",        team:"Tech",     dept:"Ingenierie", status:"Actif",  loc:"Remote",   level:"Mid",     contract:"CDI",   start:"2021-06-01",salary:52000,email:"n.petit@corp.fr",    phone:"+33 6 45 67 89 01"},
  {id:5, mat:"EMP-0005",name:"Chloe Martin",      role:"Designer UI/UX",      team:"Design",   dept:"Produit",    status:"Conge", loc:"Paris",    level:"Mid",     contract:"CDD",   start:"2022-02-14",salary:48000,email:"c.martin@corp.fr",   phone:"+33 6 56 78 90 12"},
  {id:6, mat:"EMP-0006",name:"Hugo Bernard",      role:"Data Engineer",       team:"Data",     dept:"Ingenierie", status:"Actif",  loc:"Bordeaux", level:"Senior",  contract:"CDI",   start:"2020-09-07",salary:65000,email:"h.bernard@corp.fr",  phone:"+33 6 67 89 01 23"},
  {id:7, mat:"EMP-0007",name:"Ines Rousseau",     role:"Product Manager",     team:"Produit",  dept:"Produit",    status:"Actif",  loc:"Paris",    level:"Manager", contract:"CDI",   start:"2016-11-28",salary:82000,email:"i.rousseau@corp.fr", phone:"+33 6 78 90 12 34"},
  {id:8, mat:"EMP-0008",name:"Tom Leroy",         role:"DevOps",              team:"Tech",     dept:"Ingenierie", status:"Actif",  loc:"Remote",   level:"Senior",  contract:"CDI",   start:"2019-05-20",salary:70000,email:"t.leroy@corp.fr",    phone:"+33 6 89 01 23 45"},
  {id:9, mat:"EMP-0009",name:"Lea Girard",        role:"Charge RH",           team:"RH",       dept:"RH",         status:"Actif",  loc:"Paris",    level:"Mid",     contract:"CDI",   start:"2021-01-11",salary:46000,email:"l.girard@corp.fr",   phone:"+33 6 90 12 34 56"},
  {id:10,mat:"EMP-0010",name:"Mathieu Chevalier", role:"Analyste Financier",  team:"Finance",  dept:"Finance",    status:"Inactif",loc:"Paris",    level:"Junior",  contract:"Stage", start:"2023-09-01",salary:22000,email:"m.chevalier@corp.fr",phone:"+33 6 01 23 45 67"},
  {id:11,mat:"EMP-0011",name:"Camille Dupont",    role:"Marketing Manager",   team:"Marketing",dept:"Marketing",  status:"Actif",  loc:"Nantes",   level:"Manager", contract:"CDI",   start:"2018-04-02",salary:71000,email:"c.dupont@corp.fr",   phone:"+33 6 11 22 33 44"},
  {id:12,mat:"EMP-0012",name:"Romain Blanc",      role:"Ingenieur ML",        team:"Data",     dept:"Ingenierie", status:"Actif",  loc:"Grenoble", level:"Senior",  contract:"CDI",   start:"2020-02-17",salary:78000,email:"r.blanc@corp.fr",    phone:"+33 6 22 33 44 55"},
  {id:13,mat:"EMP-0013",name:"Alice Moreau",      role:"Designer UI/UX",      team:"Design",   dept:"Produit",    status:"Conge", loc:"Paris",    level:"Junior",  contract:"CDI",   start:"2022-10-03",salary:42000,email:"a.moreau@corp.fr",   phone:"+33 6 33 44 55 66"},
  {id:14,mat:"EMP-0014",name:"Julien Simon",      role:"Scrum Master",        team:"Ops",      dept:"Operations", status:"Actif",  loc:"Toulouse", level:"Mid",     contract:"CDI",   start:"2020-08-10",salary:55000,email:"j.simon@corp.fr",    phone:"+33 6 44 55 66 77"},
  {id:15,mat:"EMP-0015",name:"Marie Fournier",    role:"Juriste",             team:"Legal",    dept:"Juridique",  status:"Actif",  loc:"Paris",    level:"Senior",  contract:"CDI",   start:"2017-06-19",salary:76000,email:"m.fournier@corp.fr", phone:"+33 6 55 66 77 88"},
];

const mkAv    = (n) => (n||"??").split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,2);
const yrs     = (d) => ((Date.now()-new Date(d))/(365.25*864e5)).toFixed(1);
const tCol    = (team,emps,th) => { const t=[...new Set(emps.map(e=>e.team))]; return th.tc[t.indexOf(team)%th.tc.length]||th.accent; };
const fmtEUR  = (n) => (n||0).toLocaleString("fr-FR")+" EUR";
const fmtDate = (d) => d ? new Date(d).toLocaleDateString("fr-FR",{day:"2-digit",month:"2-digit",year:"numeric"}) : "---";
const nextId  = (arr) => Math.max(0,...arr.map(e=>e.id||0))+1;
const genMat  = (id) => "EMP-"+String(id).padStart(4,"0");

const exportCSV = (emps) => {
  const H = ["Matricule","Nom","Poste","Equipe","Departement","Statut","Lieu","Niveau","Contrat","Date entree","Salaire","Email","Telephone"];
  const rows = emps.map(e=>[e.mat,e.name,e.role,e.team,e.dept,e.status,e.loc,e.level,e.contract,fmtDate(e.start),e.salary,e.email,e.phone]);
  const csv = [H,...rows].map(r=>r.map(v=>'"'+String(v||"").replace(/"/g,'""')+'"').join(";")).join("\n");
  const blob = new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href=url; a.download="employes.csv"; a.click(); URL.revokeObjectURL(url);
};

const exportPDF = (emps) => {
  const now = new Date().toLocaleDateString("fr-FR",{day:"2-digit",month:"long",year:"numeric"});
  const total=emps.length, active=emps.filter(e=>e.status==="Actif").length;
  const masse=emps.reduce((s,e)=>s+(e.salary||0),0);
  const rows=emps.map(e=>"<tr><td>"+e.mat+"</td><td><b>"+e.name+"</b><br><small>"+e.role+"</small></td><td>"+e.team+"</td><td>"+(e.dept||"")+"</td><td><span class='b b"+e.status+"'>"+e.status+"</span></td><td>"+(e.loc||"")+"</td><td>"+e.level+"</td><td>"+e.contract+"</td><td>"+fmtDate(e.start)+"</td><td>"+fmtEUR(e.salary)+"</td></tr>").join("");
  const html="<!DOCTYPE html><html><head><meta charset='utf-8'/><title>Rapport</title><style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:Arial,sans-serif;font-size:11px;padding:20px}.hd{display:flex;justify-content:space-between;margin-bottom:20px;padding-bottom:14px;border-bottom:2px solid #5b7fff}.logo{font-size:20px;font-weight:900;color:#5b7fff}.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:20px}.kpi{background:#f5f7ff;border:1px solid #dde;border-radius:6px;padding:10px;text-align:center}.kv{font-size:20px;font-weight:800;color:#5b7fff}.kl{font-size:9px;color:#888;text-transform:uppercase;margin-top:2px}table{width:100%;border-collapse:collapse}thead{background:#5b7fff;color:#fff}th{padding:7px 8px;font-size:9px;text-align:left;text-transform:uppercase}td{padding:6px 8px;border-bottom:1px solid #eee;vertical-align:top}tr:nth-child(even){background:#fafafe}.b{display:inline-block;padding:2px 7px;border-radius:10px;font-size:9px;font-weight:700}.bActif{background:#d1fae5;color:#065f46}.bInactif{background:#fee2e2;color:#991b1b}.bConge{background:#fef3c7;color:#92400e}.ft{margin-top:16px;padding-top:10px;border-top:1px solid #eee;display:flex;justify-content:space-between;color:#999;font-size:9px}</style></head><body><div class='hd'><div><div class='logo'>EmpManager Pro</div><div style='font-size:13px;font-weight:700;margin-top:4px'>Rapport employes</div><div style='color:#888;font-size:10px;margin-top:3px'>"+now+"</div></div><div style='text-align:right;font-size:10px;color:#555'><div>Total: <b>"+total+"</b></div><div>Actifs: "+active+"</div><div>Masse sal.: "+fmtEUR(masse)+"</div></div></div><div class='kpis'><div class='kpi'><div class='kv'>"+total+"</div><div class='kl'>Employes</div></div><div class='kpi'><div class='kv'>"+active+"</div><div class='kl'>Actifs</div></div><div class='kpi'><div class='kv'>"+[...new Set(emps.map(e=>e.team))].length+"</div><div class='kl'>Equipes</div></div><div class='kpi'><div class='kv'>"+Math.round(masse/(total||1)/1000)+"k</div><div class='kl'>Sal. moyen</div></div></div><table><thead><tr><th>Matricule</th><th>Employe</th><th>Equipe</th><th>Dept</th><th>Statut</th><th>Lieu</th><th>Niveau</th><th>Contrat</th><th>Entree</th><th>Salaire</th></tr></thead><tbody>"+rows+"</tbody></table><div class='ft'><div>EmpManager Pro v6</div><div>"+now+"</div></div><script>window.onload=function(){window.print();}<\/script></body></html>";
  const w=window.open("","_blank"); if(w){w.document.write(html);w.document.close();}
};

function GStyle({th}) {
  return <style>{"*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}body{font-family:'Segoe UI',system-ui,sans-serif}::-webkit-scrollbar{width:4px;height:4px}::-webkit-scrollbar-thumb{background:"+th.border+";border-radius:2px}input,select,button,textarea{font-family:inherit;outline:none}input::placeholder{color:"+th.muted+";opacity:.6}select option{background:"+th.surf+";color:"+th.text+"}"}</style>;
}

function Av({name, size, color}) {
  const s = size||36;
  return <div style={{width:s,height:s,borderRadius:"50%",background:"linear-gradient(135deg,"+color+"cc,"+color+"44)",border:"1.5px solid "+color+"55",display:"flex",alignItems:"center",justifyContent:"center",fontSize:Math.round(s*0.31),fontWeight:800,color:"#fff",flexShrink:0,boxShadow:"0 2px 10px "+color+"28"}}>{mkAv(name)}</div>;
}

function SBadge({status}) {
  const s = SC[status]||SC.Actif;
  return <span style={{display:"inline-flex",alignItems:"center",gap:4,padding:"3px 9px",borderRadius:20,background:s.bg,border:"1px solid "+s.c+"44",fontSize:11,fontWeight:700,color:s.c,whiteSpace:"nowrap"}}><span style={{width:6,height:6,borderRadius:"50%",background:s.c,boxShadow:"0 0 5px "+s.c}}/>{status}</span>;
}

function Combo({th, value, onChange, options, placeholder}) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState(value||"");
  useEffect(()=>{ setInput(value||""); },[value]);
  const filtered = useMemo(()=>options.filter(o=>o.toLowerCase().includes(input.toLowerCase())),[options,input]);
  const select = (v) => { setInput(v); onChange(v); setOpen(false); };
  const iSt = {background:th.bg,border:"1px solid "+th.border,borderRadius:8,padding:"8px 11px",color:th.text,fontSize:13,width:"100%"};
  return (
    <div style={{position:"relative"}}>
      <input value={input} placeholder={placeholder||"Choisir ou saisir..."}
        onChange={e=>{ setInput(e.target.value); onChange(e.target.value); setOpen(true); }}
        onFocus={()=>setOpen(true)} onBlur={()=>setTimeout(()=>setOpen(false),180)} style={iSt}/>
      {open && (
        <div style={{position:"absolute",top:"100%",left:0,right:0,zIndex:9999,background:th.surf,border:"1px solid "+th.border,borderRadius:8,marginTop:2,maxHeight:200,overflowY:"auto",boxShadow:"0 8px 24px rgba(0,0,0,.3)"}}>
          {input.trim() && !options.includes(input.trim()) && (
            <div onMouseDown={()=>select(input.trim())} style={{padding:"8px 12px",fontSize:12,color:th.accent,fontWeight:700,cursor:"pointer",borderBottom:"1px solid "+th.border}}>
              + Creer "{input.trim()}"
            </div>
          )}
          {filtered.map(o=>(
            <div key={o} onMouseDown={()=>select(o)}
              style={{padding:"8px 12px",fontSize:13,color:th.text,cursor:"pointer",background:o===value?th.soft:"transparent"}}
              onMouseEnter={e=>e.currentTarget.style.background=th.soft}
              onMouseLeave={e=>e.currentTarget.style.background=o===value?th.soft:"transparent"}>
              {o}
            </div>
          ))}
          {filtered.length===0&&!input.trim()&&<div style={{padding:"8px 12px",fontSize:12,color:th.muted}}>Aucune option</div>}
        </div>
      )}
    </div>
  );
}

function LockScreen({th, onUnlock}) {
  const [pin,setPin]=useState(""); const [err,setErr]=useState(false);
  const press=v=>{if(pin.length>=4)return;const n=pin+v;setPin(n);if(n.length===4){if(n==="1234")onUnlock();else{setErr(true);setTimeout(()=>{setPin("");setErr(false);},700);}}}; 
  return (
    <div style={{position:"fixed",inset:0,zIndex:9999,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",background:th.bg,gap:24,padding:20}}>
      <GStyle th={th}/>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:44,marginBottom:10}}>[ Lock ]</div>
        <div style={{fontWeight:800,fontSize:22,color:th.text}}>Application verrouillee</div>
        <div style={{fontSize:13,color:th.muted,marginTop:5}}>Code PIN : 1234</div>
      </div>
      <div style={{display:"flex",gap:14}}>
        {[0,1,2,3].map(i=><div key={i} style={{width:14,height:14,borderRadius:"50%",background:i<pin.length?(err?th.err:th.accent):th.border,transition:"all .2s"}}/>)}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
        {[1,2,3,4,5,6,7,8,9,"",0,"<"].map((v,i)=>(
          <button key={i} onClick={()=>{if(v==="")return;if(v==="<")setPin(p=>p.slice(0,-1));else press(String(v));}}
            style={{width:68,height:68,borderRadius:14,background:v===""?"transparent":th.card,border:v===""?"none":"1px solid "+th.border,color:th.text,fontSize:v==="<"?18:22,fontWeight:700,cursor:v===""?"default":"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>
            {v}
          </button>
        ))}
      </div>
    </div>
  );
}

function EmpForm({th, emps, emp, lists, onClose, onSave, onUpdateLists}) {
  const isEdit=!!emp, newId=nextId(emps);
  const blank={mat:genMat(newId),name:"",role:"",team:"",dept:"",status:"Actif",loc:"",level:"Mid",contract:"CDI",start:new Date().toISOString().slice(0,10),salary:"",email:"",phone:""};
  const [form,setForm]=useState(isEdit?{...emp}:blank);
  const [errs,setErrs]=useState({});
  const set=(k,v)=>setForm(f=>({...f,[k]:v}));
  const validate=()=>{const e={};if(!form.name.trim())e.name="Requis";if(!form.role.trim())e.role="Requis";if(!form.team.trim())e.team="Requis";if(!form.mat.trim())e.mat="Requis";setErrs(e);return !Object.keys(e).length;};
  const submit=()=>{
    if(!validate())return;
    onSave({...form,id:isEdit?emp.id:newId,salary:Number(form.salary)||0});
    const up={};
    if(form.team&&!lists.teams.includes(form.team))up.teams=[...lists.teams,form.team];
    if(form.dept&&!lists.depts.includes(form.dept))up.depts=[...lists.depts,form.dept];
    if(form.level&&!lists.levels.includes(form.level))up.levels=[...lists.levels,form.level];
    if(form.contract&&!lists.contracts.includes(form.contract))up.contracts=[...lists.contracts,form.contract];
    if(form.role&&!lists.roles.includes(form.role))up.roles=[...lists.roles,form.role];
    if(Object.keys(up).length)onUpdateLists(up);
    onClose();
  };
  const lbSt={fontSize:10,fontWeight:700,color:th.muted,textTransform:"uppercase",letterSpacing:".06em",marginBottom:4,display:"block"};
  const iSt={background:th.bg,border:"1px solid "+th.border,borderRadius:8,padding:"8px 11px",color:th.text,fontSize:13,width:"100%"};
  const TF=({label,fk,type,req})=><div><label style={lbSt}>{label}{req&&<span style={{color:th.err}}> *</span>}</label><input type={type||"text"} value={form[fk]||""} onChange={e=>set(fk,e.target.value)} style={{...iSt,border:"1px solid "+(errs[fk]?th.err:th.border)}} placeholder={label}/>{errs[fk]&&<div style={{fontSize:10,color:th.err,marginTop:2}}>{errs[fk]}</div>}</div>;
  const CF=({label,fk,opts,req})=><div><label style={lbSt}>{label}{req&&<span style={{color:th.err}}> *</span>}</label><Combo th={th} value={form[fk]||""} onChange={v=>set(fk,v)} options={opts}/>{errs[fk]&&<div style={{fontSize:10,color:th.err,marginTop:2}}>{errs[fk]}</div>}</div>;
  const SF=({label,fk,opts})=><div><label style={lbSt}>{label}</label><select value={form[fk]||""} onChange={e=>set(fk,e.target.value)} style={iSt}>{opts.map(o=><option key={o} value={o}>{o}</option>)}</select></div>;
  return (
    <div onClick={onClose} style={{position:"fixed",inset:0,zIndex:500,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.8)",backdropFilter:"blur(8px)",padding:16}}>
      <div onClick={e=>e.stopPropagation()} style={{background:th.surf,border:"1px solid "+th.border,borderRadius:20,width:"100%",maxWidth:600,maxHeight:"92vh",overflowY:"auto",boxShadow:"0 30px 80px rgba(0,0,0,.5)"}}>
        <div style={{height:4,background:th.grad,borderRadius:"20px 20px 0 0"}}/>
        <div style={{padding:"20px 24px"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
            <div>
              <div style={{fontWeight:800,fontSize:17,color:th.text}}>{isEdit?"Modifier l employe":"Nouvel employe"}</div>
              <div style={{fontSize:12,color:th.muted,marginTop:2}}>{isEdit?"Edition de "+emp.name:"Remplissez les informations"}</div>
            </div>
            <button onClick={onClose} style={{background:"none",border:"1px solid "+th.border,borderRadius:8,width:30,height:30,color:th.muted,fontSize:16,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>X</button>
          </div>
          <div style={{background:th.soft,border:"1px solid "+th.accent+"44",borderRadius:10,padding:"10px 14px",marginBottom:16,fontSize:12,color:th.accent}}>
            Astuce : Pour Equipe, Poste, Departement, Niveau, Contrat tapez directement pour creer une nouvelle valeur !
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
            <TF label="Matricule" fk="mat" req={true}/>
            <TF label="Nom complet" fk="name" req={true}/>
            <CF label="Poste / Fonction" fk="role" opts={lists.roles} req={true}/>
            <CF label="Equipe" fk="team" opts={lists.teams} req={true}/>
            <CF label="Departement" fk="dept" opts={lists.depts}/>
            <SF label="Statut" fk="status" opts={STATUSES}/>
            <CF label="Niveau" fk="level" opts={lists.levels}/>
            <CF label="Contrat" fk="contract" opts={lists.contracts}/>
            <TF label="Localisation" fk="loc"/>
            <TF label="Date d entree" fk="start" type="date"/>
            <TF label="Salaire annuel EUR" fk="salary" type="number"/>
            <TF label="Email" fk="email" type="email"/>
            <div style={{gridColumn:"1/-1"}}><TF label="Telephone" fk="phone"/></div>
          </div>
          <div style={{display:"flex",gap:8,justifyContent:"flex-end",marginTop:18,paddingTop:16,borderTop:"1px solid "+th.border}}>
            <button onClick={onClose} style={{background:"none",border:"1px solid "+th.border,borderRadius:9,padding:"8px 20px",color:th.muted,fontSize:13,fontWeight:600,cursor:"pointer"}}>Annuler</button>
            <button onClick={submit} style={{background:th.grad,border:"none",borderRadius:9,padding:"8px 24px",color:"#fff",fontSize:13,fontWeight:700,cursor:"pointer",boxShadow:"0 4px 14px "+th.accent+"44"}}>{isEdit?"Enregistrer":"Ajouter"}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ConfirmDel({th, title, desc, onClose, onOk}) {
  return (
    <div onClick={onClose} style={{position:"fixed",inset:0,zIndex:600,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.82)",backdropFilter:"blur(8px)",padding:16}}>
      <div onClick={e=>e.stopPropagation()} style={{background:th.surf,border:"1px solid "+th.err+"44",borderRadius:18,width:"100%",maxWidth:380,overflow:"hidden",boxShadow:"0 24px 60px rgba(0,0,0,.5)"}}>
        <div style={{height:4,background:th.err}}/>
        <div style={{padding:"22px"}}>
          <div style={{fontSize:28,textAlign:"center",marginBottom:10,color:th.warn}}>!</div>
          <div style={{fontWeight:800,fontSize:17,color:th.text,textAlign:"center",marginBottom:6}}>{title}</div>
          <div style={{fontSize:12,color:th.muted,textAlign:"center",marginBottom:20}}>{desc}</div>
          <div style={{display:"flex",gap:8}}>
            <button onClick={onClose} style={{flex:1,background:"none",border:"1px solid "+th.border,borderRadius:9,padding:"10px",color:th.muted,fontSize:13,fontWeight:600,cursor:"pointer"}}>Annuler</button>
            <button onClick={onOk} style={{flex:1,background:th.err,border:"none",borderRadius:9,padding:"10px",color:"#fff",fontSize:13,fontWeight:700,cursor:"pointer"}}>Supprimer</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Drawer({th, emp, emps, onClose, onEdit, onDelete}) {
  if(!emp)return null;
  const c=tCol(emp.team,emps,th);
  return (
    <>
      <div onClick={onClose} style={{position:"fixed",inset:0,zIndex:200,background:"rgba(0,0,0,.4)"}}/>
      <div style={{position:"fixed",right:0,top:0,bottom:0,zIndex:201,width:"min(400px,95vw)",background:th.surf,borderLeft:"1px solid "+th.border,display:"flex",flexDirection:"column",boxShadow:"-6px 0 32px rgba(0,0,0,.3)"}}>
        <div style={{height:4,background:"linear-gradient(90deg,"+c+","+c+"00)"}}/>
        <div style={{padding:"16px 18px",borderBottom:"1px solid "+th.border,display:"flex",alignItems:"center",gap:12}}>
          <Av name={emp.name} size={48} color={c}/>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontWeight:800,fontSize:16,color:th.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{emp.name}</div>
            <div style={{fontSize:12,color:th.muted,marginTop:2}}>{emp.role}</div>
            <div style={{fontSize:11,color:th.accent,fontFamily:"monospace",marginTop:2}}>{emp.mat}</div>
            <div style={{marginTop:5}}><SBadge status={emp.status}/></div>
          </div>
          <button onClick={onClose} style={{background:"none",border:"1px solid "+th.border,borderRadius:8,width:30,height:30,color:th.muted,fontSize:16,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>X</button>
        </div>
        <div style={{flex:1,overflowY:"auto",padding:"14px"}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:10}}>
            {[{l:"Matricule",v:emp.mat,col:th.accent},{l:"Equipe",v:emp.team,col:c},{l:"Departement",v:emp.dept||"---"},{l:"Lieu",v:emp.loc||"---"},{l:"Niveau",v:emp.level},{l:"Contrat",v:emp.contract},{l:"Anciennete",v:yrs(emp.start)+" ans"},{l:"Date entree",v:fmtDate(emp.start)}].map(({l,v,col})=>(
              <div key={l} style={{background:th.card,borderRadius:9,padding:"9px 11px"}}>
                <div style={{fontSize:9,fontWeight:700,color:th.muted,textTransform:"uppercase",letterSpacing:".08em",marginBottom:3}}>{l}</div>
                <div style={{fontSize:13,fontWeight:600,color:col||th.text}}>{v}</div>
              </div>
            ))}
          </div>
          {(emp.email||emp.phone)&&<div style={{background:th.card,borderRadius:9,padding:"11px 13px",marginBottom:10}}>
            <div style={{fontSize:9,fontWeight:700,color:th.muted,textTransform:"uppercase",letterSpacing:".08em",marginBottom:7}}>Coordonnees</div>
            {emp.email&&<div style={{fontSize:12,color:th.text,marginBottom:4}}>Email : {emp.email}</div>}
            {emp.phone&&<div style={{fontSize:12,color:th.text}}>Tel : {emp.phone}</div>}
          </div>}
          <div style={{background:th.card,borderRadius:9,padding:"12px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div>
              <div style={{fontSize:9,fontWeight:700,color:th.muted,textTransform:"uppercase",letterSpacing:".08em",marginBottom:3}}>Salaire annuel</div>
              <div style={{fontSize:20,fontWeight:800,color:th.accent,fontFamily:"monospace"}}>{fmtEUR(emp.salary)}</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:9,fontWeight:700,color:th.muted,textTransform:"uppercase",letterSpacing:".08em",marginBottom:3}}>Date entree</div>
              <div style={{fontSize:12,fontWeight:600,color:th.text}}>{fmtDate(emp.start)}</div>
            </div>
          </div>
        </div>
        <div style={{padding:"12px 14px",borderTop:"1px solid "+th.border,display:"flex",gap:8}}>
          <button onClick={()=>{onEdit(emp);onClose();}} style={{flex:1,background:th.soft,border:"1px solid "+th.accent+"44",borderRadius:9,padding:"9px",color:th.accent,fontSize:13,fontWeight:700,cursor:"pointer"}}>Modifier</button>
          <button onClick={()=>{onDelete(emp);onClose();}} style={{flex:1,background:"#ff4d6d18",border:"1px solid #ff4d6d44",borderRadius:9,padding:"9px",color:"#ff4d6d",fontSize:13,fontWeight:700,cursor:"pointer"}}>Supprimer</button>
        </div>
      </div>
    </>
  );
}

function ListManager({th, lists, onUpdateLists}) {
  const [adding,setAdding]=useState({});
  const [editing,setEditing]=useState(null);
  const SECTIONS=[{key:"teams",label:"Equipes"},{key:"depts",label:"Departements"},{key:"levels",label:"Niveaux"},{key:"contracts",label:"Contrats"},{key:"roles",label:"Fonctions / Postes"}];
  const addItem=(key)=>{const v=(adding[key]||"").trim();if(!v||lists[key].includes(v))return;onUpdateLists({[key]:[...lists[key],v]});setAdding(a=>({...a,[key]:""}));};
  const removeItem=(key,idx)=>onUpdateLists({[key]:lists[key].filter((_,i)=>i!==idx)});
  const saveEdit=()=>{if(!editing)return;const{key,idx,val}=editing;if(!val.trim())return;const u=[...lists[key]];u[idx]=val.trim();onUpdateLists({[key]:u});setEditing(null);};
  return (
    <div style={{display:"flex",flexDirection:"column",gap:20}}>
      <div>
        <div style={{fontWeight:800,fontSize:18,color:th.text}}>Gestion des listes</div>
        <div style={{fontSize:12,color:th.muted,marginTop:2}}>Ajouter, modifier ou supprimer equipes, postes, niveaux, contrats, departements</div>
      </div>
      {SECTIONS.map(({key,label})=>(
        <div key={key} style={{background:th.card,border:"1px solid "+th.border,borderRadius:14,overflow:"hidden"}}>
          <div style={{padding:"14px 18px",borderBottom:"1px solid "+th.border,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{fontWeight:700,fontSize:13,color:th.text}}>{label}</div>
            <span style={{fontSize:11,color:th.muted}}>{lists[key].length} element(s)</span>
          </div>
          <div style={{padding:"14px 18px"}}>
            <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:14}}>
              {lists[key].map((item,idx)=>(
                <div key={idx} style={{display:"flex",alignItems:"center",background:th.bg,border:"1px solid "+th.border,borderRadius:8,overflow:"hidden"}}>
                  {editing&&editing.key===key&&editing.idx===idx?(
                    <input autoFocus value={editing.val} onChange={e=>setEditing(ei=>({...ei,val:e.target.value}))} onKeyDown={e=>{if(e.key==="Enter")saveEdit();if(e.key==="Escape")setEditing(null);}} style={{background:"transparent",border:"none",color:th.text,fontSize:12,padding:"5px 10px",width:130}}/>
                  ):(
                    <span style={{fontSize:12,fontWeight:600,color:th.text,padding:"5px 10px"}}>{item}</span>
                  )}
                  <div style={{display:"flex",borderLeft:"1px solid "+th.border}}>
                    {editing&&editing.key===key&&editing.idx===idx?(
                      <button onClick={saveEdit} style={{background:"none",border:"none",color:th.ok,fontSize:12,cursor:"pointer",padding:"5px 8px"}}>OK</button>
                    ):(
                      <button onClick={()=>setEditing({key,idx,val:item})} style={{background:"none",border:"none",color:th.muted,fontSize:12,cursor:"pointer",padding:"5px 8px"}} onMouseEnter={e=>e.target.style.color=th.accent} onMouseLeave={e=>e.target.style.color=th.muted}>E</button>
                    )}
                    <button onClick={()=>removeItem(key,idx)} style={{background:"none",border:"none",color:th.muted,fontSize:12,cursor:"pointer",padding:"5px 8px"}} onMouseEnter={e=>e.target.style.color=th.err} onMouseLeave={e=>e.target.style.color=th.muted}>X</button>
                  </div>
                </div>
              ))}
            </div>
            <div style={{display:"flex",gap:8}}>
              <input value={adding[key]||""} onChange={e=>setAdding(a=>({...a,[key]:e.target.value}))} onKeyDown={e=>{if(e.key==="Enter")addItem(key);}} placeholder={"Nouveau "+label.toLowerCase()+"..."} style={{flex:1,background:th.bg,border:"1px solid "+th.border,borderRadius:8,padding:"8px 12px",color:th.text,fontSize:13}}/>
              <button onClick={()=>addItem(key)} style={{background:th.grad,border:"none",borderRadius:8,padding:"8px 16px",color:"#fff",fontSize:12,fontWeight:700,cursor:"pointer"}}>+ Ajouter</button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function Dashboard({th, emps}) {
  const active=emps.filter(e=>e.status==="Actif").length;
  const totalS=emps.reduce((s,e)=>s+(e.salary||0),0);
  const tC=emps.reduce((a,e)=>{a[e.team]=(a[e.team]||0)+1;return a;},{});
  const lC={Manager:0,Senior:0,Mid:0,Junior:0};emps.forEach(e=>{if(lC[e.level]!==undefined)lC[e.level]++;});
  const Bar=({lbl,count,total,color})=>(
    <div style={{display:"flex",alignItems:"center",gap:10,padding:"5px 0",borderBottom:"1px solid "+th.border}}>
      <div style={{width:"30%",fontSize:11,color:th.muted,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{lbl}</div>
      <div style={{flex:1,height:7,background:th.bg,borderRadius:3,overflow:"hidden"}}><div style={{width:total?Math.round(count/total*100)+"%":"0%",height:"100%",background:color,borderRadius:3}}/></div>
      <div style={{fontSize:11,fontWeight:700,color:th.text,width:22,textAlign:"right",fontFamily:"monospace"}}>{count}</div>
    </div>
  );
  return (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:10}}>
        {[{l:"Total",v:emps.length,c:th.accent,s:"effectif global"},{l:"Actifs",v:active,c:th.ok,s:emps.length?Math.round(active/emps.length*100)+"%":"0%"},{l:"En conge",v:emps.filter(e=>e.status==="Conge").length,c:th.warn,s:emps.filter(e=>e.status==="Inactif").length+" inactif(s)"},{l:"Sal. moyen",v:Math.round(emps.length?totalS/emps.length/1000:0)+"k",c:"#a78bfa",s:"EUR annuel brut"}].map(({l,v,c,s})=>(
          <div key={l} style={{background:th.card,border:"1px solid "+th.border,borderRadius:12,padding:"16px",position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",top:0,left:0,width:3,height:"100%",background:c}}/>
            <div style={{fontSize:26,fontWeight:800,color:th.text,fontFamily:"monospace",lineHeight:1}}>{v}</div>
            <div style={{fontSize:12,fontWeight:600,color:th.text,marginTop:4}}>{l}</div>
            <div style={{fontSize:11,color:th.muted,marginTop:2}}>{s}</div>
          </div>
        ))}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(250px,1fr))",gap:14}}>
        <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:12,padding:"16px"}}>
          <div style={{fontWeight:700,fontSize:13,color:th.text,marginBottom:12}}>Par equipe</div>
          {Object.entries(tC).sort(([,a],[,b])=>b-a).map(([t,n],i)=><Bar key={t} lbl={t} count={n} total={emps.length} color={th.tc[i%th.tc.length]}/>)}
        </div>
        <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:12,padding:"16px"}}>
          <div style={{fontWeight:700,fontSize:13,color:th.text,marginBottom:12}}>Niveaux</div>
          {["Manager","Senior","Mid","Junior"].filter(l=>lC[l]>0).map(l=>{const cols={Manager:"#a78bfa",Senior:th.accent,Mid:th.ok,Junior:th.warn};return <Bar key={l} lbl={l} count={lC[l]} total={emps.length} color={cols[l]}/>;})}</div>
      </div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:12,padding:"16px"}}>
        <div style={{fontWeight:700,fontSize:13,color:th.text,marginBottom:12}}>Analyse salariale</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:10}}>
          {[{l:"Masse totale",v:fmtEUR(totalS),c:th.accent},{l:"Mediane",v:emps.length?Math.round([...emps].sort((a,b)=>(a.salary||0)-(b.salary||0))[Math.floor(emps.length/2)]?.salary/1000)+"k":"---",c:th.ok},{l:"Maximum",v:emps.length?fmtEUR(Math.max(...emps.map(e=>e.salary||0))):"---",c:"#a78bfa"},{l:"Minimum",v:emps.length?fmtEUR(Math.min(...emps.filter(e=>e.salary>0).map(e=>e.salary))):"---",c:th.warn}].map(({l,v,c})=>(
            <div key={l} style={{background:th.bg,borderRadius:9,padding:"11px 12px",border:"1px solid "+c+"22"}}>
              <div style={{fontSize:9,fontWeight:700,color:th.muted,textTransform:"uppercase",letterSpacing:".07em",marginBottom:5}}>{l}</div>
              <div style={{fontSize:15,fontWeight:800,color:c,fontFamily:"monospace"}}>{v}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function EmpTable({th, emps, lists, onSel, onEdit, onDel, onAdd}) {
  const [q,setQ]=useState(""); const [f,setF]=useState({status:"all",team:"all",level:"all",contract:"all"}); const [sort,setSort]=useState({by:"name",dir:"asc"});
  const setFk=(k,v)=>setF(p=>({...p,[k]:v}));
  const activeF=Object.values(f).filter(v=>v!=="all").length+(q?1:0);
  const ts=k=>{if(sort.by===k)setSort(s=>({...s,dir:s.dir==="asc"?"desc":"asc"}));else setSort({by:k,dir:"asc"});};
  const filtered=useMemo(()=>emps.filter(e=>{const lo=q.toLowerCase();if(q&&![e.mat,e.name,e.role,e.team,e.dept].some(v=>(v||"").toLowerCase().includes(lo)))return false;if(f.status!=="all"&&e.status!==f.status)return false;if(f.team!=="all"&&e.team!==f.team)return false;if(f.level!=="all"&&e.level!==f.level)return false;if(f.contract!=="all"&&e.contract!==f.contract)return false;return true;}).sort((a,b)=>{let va=a[sort.by]||"",vb=b[sort.by]||"";if(sort.by==="salary"){va=+(a.salary||0);vb=+(b.salary||0);}if(sort.by==="start"){va=new Date(a.start||0);vb=new Date(b.start||0);}return(va<vb?-1:va>vb?1:0)*(sort.dir==="asc"?1:-1);}),[emps,q,f,sort]);
  const sSt={background:th.bg,border:"1px solid "+th.border,borderRadius:8,padding:"6px 9px",color:th.text,fontSize:12};
  const allTeams=["all",...[...new Set(emps.map(e=>e.team))]];
  const allLevels=["all",...[...new Set(emps.map(e=>e.level))]];
  const allContracts=["all",...[...new Set(emps.map(e=>e.contract))]];
  const Th=({lbl,k,w})=><th onClick={()=>ts(k)} style={{padding:"9px 11px",textAlign:"left",fontSize:10,fontWeight:700,color:sort.by===k?th.accent:th.muted,textTransform:"uppercase",letterSpacing:".07em",cursor:"pointer",whiteSpace:"nowrap",userSelect:"none",width:w}}>{lbl}{sort.by===k?(sort.dir==="asc"?" v":" ^"):""}</th>;
  return (
    <div style={{display:"flex",flexDirection:"column",gap:12}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:10}}>
        <div>
          <div style={{fontWeight:800,fontSize:18,color:th.text}}>Employes</div>
          <div style={{fontSize:12,color:th.muted,marginTop:2}}>{filtered.length}/{emps.length} employe(s)</div>
        </div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          <button onClick={()=>exportCSV(filtered)} style={{background:th.card,border:"1px solid "+th.ok+"66",borderRadius:9,padding:"7px 14px",color:th.ok,fontSize:12,fontWeight:700,cursor:"pointer"}}>Excel CSV</button>
          <button onClick={()=>exportPDF(filtered)} style={{background:th.card,border:"1px solid "+th.err+"66",borderRadius:9,padding:"7px 14px",color:th.err,fontSize:12,fontWeight:700,cursor:"pointer"}}>PDF</button>
          <button onClick={onAdd} style={{background:th.grad,border:"none",borderRadius:9,padding:"7px 16px",color:"#fff",fontSize:12,fontWeight:700,cursor:"pointer",boxShadow:"0 4px 12px "+th.accent+"44"}}>+ Ajouter</button>
        </div>
      </div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:11,padding:"11px 13px",display:"flex",gap:8,flexWrap:"wrap",alignItems:"flex-end"}}>
        <div style={{flex:"1 1 200px"}}><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Rechercher matricule, nom, equipe..." style={{...sSt,width:"100%",fontSize:13}}/></div>
        {[["status","Statut",["all",...STATUSES]],["team","Equipe",allTeams],["level","Niveau",allLevels],["contract","Contrat",allContracts]].map(([k,l,opts])=>(
          <div key={k}><label style={{fontSize:9,fontWeight:700,color:th.muted,textTransform:"uppercase",letterSpacing:".07em",display:"block",marginBottom:3}}>{l}</label><select value={f[k]} onChange={e=>setFk(k,e.target.value)} style={{...sSt,border:"1px solid "+(f[k]!=="all"?th.accent:th.border)}}>{opts.map(o=><option key={o} value={o}>{o==="all"?"Tous":o}</option>)}</select></div>
        ))}
        {activeF>0&&<button onClick={()=>{setF({status:"all",team:"all",level:"all",contract:"all"});setQ("");}} style={{background:"none",border:"1px solid "+th.err+"44",borderRadius:8,padding:"6px 10px",color:th.err,fontSize:11,fontWeight:600,cursor:"pointer",alignSelf:"flex-end"}}>X Reset</button>}
      </div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:11,overflow:"hidden"}}>
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse",minWidth:780}}>
            <thead style={{background:th.bg,borderBottom:"1px solid "+th.border}}><tr><Th lbl="Matricule" k="mat" w="110px"/><Th lbl="Employe" k="name" w="200px"/><Th lbl="Poste" k="role" w="160px"/><Th lbl="Equipe" k="team" w="100px"/><Th lbl="Niveau" k="level" w="80px"/><Th lbl="Statut" k="status" w="90px"/><Th lbl="Contrat" k="contract" w="80px"/><Th lbl="Salaire" k="salary" w="110px"/><Th lbl="Anc." k="start" w="60px"/><th style={{padding:"9px 11px",width:72}}></th></tr></thead>
            <tbody>
              {filtered.length===0&&<tr><td colSpan={10} style={{textAlign:"center",padding:40,color:th.muted}}><div style={{fontSize:24,marginBottom:6}}>?</div><div>Aucun resultat</div></td></tr>}
              {filtered.map(emp=>{
                const c=tCol(emp.team,emps,th);
                return (
                  <tr key={emp.id} style={{borderBottom:"1px solid "+th.border,cursor:"pointer",transition:"background .1s"}} onMouseEnter={e=>e.currentTarget.style.background=th.soft} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                    <td style={{padding:"9px 11px"}} onClick={()=>onSel(emp)}><span style={{fontFamily:"monospace",fontSize:11,fontWeight:700,color:th.accent}}>{emp.mat}</span></td>
                    <td style={{padding:"9px 11px"}} onClick={()=>onSel(emp)}><div style={{display:"flex",alignItems:"center",gap:9}}><Av name={emp.name} size={30} color={c}/><div><div style={{fontWeight:700,fontSize:12,color:th.text}}>{emp.name}</div><div style={{fontSize:10,color:th.muted}}>{emp.dept}</div></div></div></td>
                    <td style={{padding:"9px 11px",fontSize:11,color:th.muted}} onClick={()=>onSel(emp)}>{emp.role}</td>
                    <td style={{padding:"9px 11px"}} onClick={()=>onSel(emp)}><span style={{background:c+"22",color:c,border:"1px solid "+c+"44",padding:"2px 7px",borderRadius:8,fontSize:10,fontWeight:600,whiteSpace:"nowrap"}}>{emp.team}</span></td>
                    <td style={{padding:"9px 11px",fontSize:11,color:th.muted}} onClick={()=>onSel(emp)}>{emp.level}</td>
                    <td style={{padding:"9px 11px"}} onClick={()=>onSel(emp)}><SBadge status={emp.status}/></td>
                    <td style={{padding:"9px 11px",fontSize:11,color:th.muted}} onClick={()=>onSel(emp)}>{emp.contract}</td>
                    <td style={{padding:"9px 11px",fontSize:11,fontWeight:600,color:th.text,fontFamily:"monospace"}} onClick={()=>onSel(emp)}>{fmtEUR(emp.salary)}</td>
                    <td style={{padding:"9px 11px",fontSize:11,color:th.muted}} onClick={()=>onSel(emp)}>{yrs(emp.start)}a</td>
                    <td style={{padding:"9px 11px"}}>
                      <div style={{display:"flex",gap:3}}>
                        <button onClick={e=>{e.stopPropagation();onEdit(emp);}} style={{background:"none",border:"1px solid "+th.border,borderRadius:6,width:28,height:28,color:th.muted,fontSize:13,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}} onMouseEnter={e=>{e.currentTarget.style.color=th.accent;e.currentTarget.style.borderColor=th.accent;}} onMouseLeave={e=>{e.currentTarget.style.color=th.muted;e.currentTarget.style.borderColor=th.border;}}>E</button>
                        <button onClick={e=>{e.stopPropagation();onDel(emp);}} style={{background:"none",border:"1px solid "+th.border,borderRadius:6,width:28,height:28,color:th.muted,fontSize:13,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}} onMouseEnter={e=>{e.currentTarget.style.color=th.err;e.currentTarget.style.borderColor=th.err;}} onMouseLeave={e=>{e.currentTarget.style.color=th.muted;e.currentTarget.style.borderColor=th.border;}}>X</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function TeamsView({th, emps, onEditEmp, onDelEmp}) {
  const [open,setOpen]=useState({});
  const groups=useMemo(()=>{const g={};emps.forEach(e=>{if(!g[e.team])g[e.team]=[];g[e.team].push(e);});return g;},[emps]);
  return (
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:10}}>
        <div><div style={{fontWeight:800,fontSize:18,color:th.text}}>Equipes</div><div style={{fontSize:12,color:th.muted,marginTop:2}}>{Object.keys(groups).length} equipes</div></div>
        <div style={{display:"flex",gap:8}}>
          <button onClick={()=>exportCSV(emps)} style={{background:th.card,border:"1px solid "+th.ok+"66",borderRadius:9,padding:"7px 14px",color:th.ok,fontSize:12,fontWeight:700,cursor:"pointer"}}>Excel CSV</button>
          <button onClick={()=>exportPDF(emps)} style={{background:th.card,border:"1px solid "+th.err+"66",borderRadius:9,padding:"7px 14px",color:th.err,fontSize:12,fontWeight:700,cursor:"pointer"}}>PDF</button>
        </div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(120px,1fr))",gap:8}}>
        {Object.entries(groups).map(([team,members],i)=>{const c=th.tc[i%th.tc.length];return <div key={team} onClick={()=>setOpen(o=>({...o,[team]:!o[team]}))} style={{background:th.card,border:"1px solid "+(open[team]?c:th.border),borderRadius:10,padding:"12px",cursor:"pointer",transition:"all .15s"}} onMouseEnter={e=>e.currentTarget.style.borderColor=c} onMouseLeave={e=>e.currentTarget.style.borderColor=open[team]?c:th.border}><div style={{fontWeight:700,fontSize:12,color:th.text,marginBottom:4}}>{team}</div><div style={{fontSize:20,fontWeight:800,color:c,fontFamily:"monospace"}}>{members.length}</div><div style={{fontSize:10,color:th.muted,marginTop:2}}>{members.filter(m=>m.status==="Actif").length} actifs</div></div>;})}
      </div>
      {Object.entries(groups).map(([team,members],ti)=>{
        const c=th.tc[ti%th.tc.length]; const isOpen=open[team];
        const mgrs=members.filter(m=>m.level==="Manager"); const srs=members.filter(m=>m.level==="Senior"); const rest=members.filter(m=>!["Manager","Senior"].includes(m.level));
        return (
          <div key={team} style={{background:th.card,border:"1px solid "+(isOpen?c:th.border),borderRadius:13,overflow:"hidden",transition:"border-color .2s"}}>
            <div onClick={()=>setOpen(o=>({...o,[team]:!o[team]}))} style={{padding:"13px 16px",display:"flex",alignItems:"center",gap:12,cursor:"pointer",background:isOpen?c+"0a":"transparent"}}>
              <div style={{width:38,height:38,borderRadius:10,background:c+"33",border:"1.5px solid "+c+"44",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0,color:th.text,fontWeight:800,fontFamily:"monospace"}}>{team.slice(0,2).toUpperCase()}</div>
              <div style={{flex:1}}><div style={{fontWeight:700,fontSize:14,color:th.text}}>{team}</div><div style={{fontSize:11,color:th.muted}}>{members.length} membre(s) - {members.filter(m=>m.status==="Actif").length} actifs</div></div>
              <div style={{display:"flex"}}>{members.slice(0,4).map((m,i)=><div key={m.id} style={{marginLeft:i>0?-8:0,zIndex:4-i}}><Av name={m.name} size={26} color={c}/></div>)}{members.length>4&&<div style={{marginLeft:-8,width:26,height:26,borderRadius:"50%",background:th.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,fontWeight:700,color:th.muted,border:"1px solid "+th.border}}>+{members.length-4}</div>}</div>
              <span style={{color:th.muted,transform:isOpen?"rotate(90deg)":"none",transition:"transform .2s",display:"inline-block"}}>{">"}</span>
            </div>
            {isOpen&&<div style={{padding:"12px 16px",borderTop:"1px solid "+th.border,display:"flex",flexDirection:"column",gap:10}}>
              {[["Management",mgrs],["Seniors",srs],["Equipe",rest]].filter(([,arr])=>arr.length>0).map(([lbl,arr])=>(
                <div key={lbl}><div style={{fontSize:9,fontWeight:700,color:lbl==="Management"?c:th.muted,textTransform:"uppercase",letterSpacing:".08em",marginBottom:7}}>{lbl}</div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:6}}>{arr.map(m=><div key={m.id} style={{background:th.bg,borderRadius:8,padding:"8px 10px",border:"1px solid "+th.border,display:"flex",alignItems:"center",gap:8}}><Av name={m.name} size={28} color={c}/><div style={{flex:1,minWidth:0}}><div style={{fontSize:11,fontWeight:700,color:th.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{m.name}</div><div style={{fontSize:9,color:th.accent,fontFamily:"monospace"}}>{m.mat}</div><div style={{fontSize:9,color:th.muted}}>{m.role}</div></div><div style={{display:"flex",gap:2}}><button onClick={()=>onEditEmp(m)} style={{background:"none",border:"none",color:th.muted,fontSize:12,cursor:"pointer"}} onMouseEnter={e=>e.target.style.color=th.accent} onMouseLeave={e=>e.target.style.color=th.muted}>E</button><button onClick={()=>onDelEmp(m)} style={{background:"none",border:"none",color:th.muted,fontSize:12,cursor:"pointer"}} onMouseEnter={e=>e.target.style.color=th.err} onMouseLeave={e=>e.target.style.color=th.muted}>X</button></div></div>)}</div></div>
              ))}
            </div>}
          </div>
        );
      })}
    </div>
  );
}

function FunctionsView({th, emps}) {
  const byLevel=useMemo(()=>{const g={};emps.forEach(e=>{if(!g[e.level])g[e.level]=[];g[e.level].push(e);});return g;},[emps]);
  const byDept=useMemo(()=>{const g={};emps.forEach(e=>{if(!g[e.dept])g[e.dept]=[];g[e.dept].push(e);});return g;},[emps]);
  const allLevels=[...new Set(emps.map(e=>e.level))];
  const levelColors={Manager:"#a78bfa",Senior:"#5b7fff",Mid:"#22d48c",Junior:"#f5a623",Directeur:"#f472b6",VP:"#34d399"};
  const allRoles=useMemo(()=>{const m={};emps.forEach(e=>{const k=e.role+"|"+e.team;if(!m[k])m[k]={role:e.role,team:e.team,level:e.level,count:0};m[k].count++;});return Object.values(m).sort((a,b)=>a.role.localeCompare(b.role));},[emps]);
  return (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div><div style={{fontWeight:800,fontSize:18,color:th.text}}>Fonctions et Niveaux</div><div style={{fontSize:12,color:th.muted,marginTop:2}}>Pyramide hierarchique et postes</div></div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:12,padding:"16px"}}>
        <div style={{fontWeight:700,fontSize:13,color:th.text,marginBottom:14}}>Pyramide hierarchique</div>
        {allLevels.map((level,i)=>{const members=byLevel[level]||[];if(!members.length)return null;const pct=Math.max(30,Math.min(100,Math.round(30+(i/Math.max(allLevels.length-1,1))*70)));const c=levelColors[level]||th.tc[i%th.tc.length];return <div key={level} style={{marginBottom:9,display:"flex",alignItems:"center",gap:10}}><div style={{width:70,fontSize:11,fontWeight:700,color:c,flexShrink:0}}>{level}</div><div style={{flex:1,maxWidth:pct+"%",height:36,background:c+"1e",border:"1px solid "+c+"44",borderRadius:8,display:"flex",alignItems:"center",padding:"0 8px",gap:5,overflow:"hidden"}}>{members.slice(0,8).map(m=><Av key={m.id} name={m.name} size={24} color={c}/>)}{members.length>8&&<span style={{fontSize:10,color:c,fontWeight:700}}>+{members.length-8}</span>}</div><div style={{fontSize:13,fontWeight:700,color:th.text,width:24,fontFamily:"monospace"}}>{members.length}</div></div>;})}
      </div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:12,padding:"16px"}}>
        <div style={{fontWeight:700,fontSize:13,color:th.text,marginBottom:12}}>Par departement</div>
        {Object.entries(byDept).map(([dept,members],i)=>{const c=th.tc[i%th.tc.length];const lvls={};members.forEach(m=>{lvls[m.level]=(lvls[m.level]||0)+1;});return <div key={dept} style={{background:th.bg,borderRadius:9,padding:"10px 13px",border:"1px solid "+c+"22",display:"flex",alignItems:"center",flexWrap:"wrap",gap:8,marginBottom:7}}><div style={{display:"flex",alignItems:"center",gap:7,flex:"1 1 140px"}}><div style={{width:7,height:7,borderRadius:"50%",background:c}}/><div style={{fontWeight:700,fontSize:12,color:th.text}}>{dept}</div><div style={{fontSize:12,fontWeight:700,color:c,marginLeft:"auto",fontFamily:"monospace"}}>{members.length}</div></div><div style={{display:"flex",gap:5,flexWrap:"wrap"}}>{Object.entries(lvls).map(([l,n])=><span key={l} style={{background:(levelColors[l]||th.accent)+"20",color:levelColors[l]||th.accent,border:"1px solid "+(levelColors[l]||th.accent)+"40",padding:"1px 7px",borderRadius:7,fontSize:10,fontWeight:600}}>{l}: {n}</span>)}</div></div>;})}
      </div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:12,padding:"16px"}}>
        <div style={{fontWeight:700,fontSize:13,color:th.text,marginBottom:12}}>Tous les postes ({allRoles.length})</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:8}}>
          {allRoles.map((r,i)=>{const c=tCol(r.team,emps,th);return <div key={i} style={{background:th.bg,borderRadius:9,padding:"10px 13px",border:"1px solid "+th.border,display:"flex",alignItems:"center",gap:10}}><div style={{width:8,height:8,borderRadius:"50%",background:levelColors[r.level]||th.accent,flexShrink:0}}/><div style={{flex:1,minWidth:0}}><div style={{fontSize:12,fontWeight:700,color:th.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{r.role}</div><div style={{fontSize:10,color:th.muted}}><span style={{color:c}}>{r.team}</span> - {r.level} - {r.count} emp.</div></div></div>;})}
        </div>
      </div>
    </div>
  );
}

function SettingsView({th, thKey, setThKey, onLock, emps}) {
  return (
    <div style={{display:"flex",flexDirection:"column",gap:16,maxWidth:720}}>
      <div><div style={{fontWeight:800,fontSize:18,color:th.text}}>Parametres</div><div style={{fontSize:12,color:th.muted,marginTop:2}}>Themes, exports, securite</div></div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:13,overflow:"hidden"}}>
        <div style={{padding:"14px 18px",borderBottom:"1px solid "+th.border}}><div style={{fontWeight:700,fontSize:13,color:th.text}}>Theme de l interface</div></div>
        <div style={{padding:"16px 18px",display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(110px,1fr))",gap:10}}>
          {Object.entries(THEMES).map(([k,t])=>{const active=thKey===k;return <button key={k} onClick={()=>setThKey(k)} style={{background:t.surf,border:"2px solid "+(active?t.accent:t.border),borderRadius:11,padding:"12px 8px",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:6,transition:"all .18s",transform:active?"scale(1.04)":"scale(1)",boxShadow:active?"0 4px 18px "+t.accent+"44":"none"}}><div style={{width:32,height:32,borderRadius:9,background:t.grad,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:800,color:"#fff"}}>{t.name.slice(0,2)}</div><div style={{fontSize:11,fontWeight:700,color:t.text}}>{t.name}</div><div style={{display:"flex",gap:2}}>{t.tc.slice(0,5).map((c,i)=><div key={i} style={{width:6,height:6,borderRadius:"50%",background:c}}/>)}</div>{active&&<div style={{fontSize:9,fontWeight:700,color:t.accent}}>Actif</div>}</button>;})}
        </div>
      </div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:13,overflow:"hidden"}}>
        <div style={{padding:"14px 18px",borderBottom:"1px solid "+th.border}}><div style={{fontWeight:700,fontSize:13,color:th.text}}>Exports</div></div>
        <div style={{padding:"14px 18px",display:"flex",gap:12,flexWrap:"wrap"}}>
          <button onClick={()=>exportCSV(emps)} style={{background:th.ok+"18",border:"1px solid "+th.ok+"44",borderRadius:10,padding:"12px 20px",color:th.ok,fontSize:13,fontWeight:700,cursor:"pointer"}}>Exporter Excel / CSV ({emps.length} employes)</button>
          <button onClick={()=>exportPDF(emps)} style={{background:th.err+"18",border:"1px solid "+th.err+"44",borderRadius:10,padding:"12px 20px",color:th.err,fontSize:13,fontWeight:700,cursor:"pointer"}}>Exporter PDF (rapport complet)</button>
        </div>
      </div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:13,overflow:"hidden"}}>
        <div style={{padding:"14px 18px",borderBottom:"1px solid "+th.border}}><div style={{fontWeight:700,fontSize:13,color:th.text}}>Securite</div></div>
        <div style={{padding:"14px 18px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
          <div><div style={{fontSize:13,fontWeight:600,color:th.text}}>Verrouiller l application</div><div style={{fontSize:11,color:th.muted,marginTop:2}}>Code PIN : 1234</div></div>
          <button onClick={onLock} style={{background:"#ff4d6d1a",border:"1px solid #ff4d6d44",borderRadius:9,padding:"8px 16px",color:"#ff4d6d",fontSize:12,fontWeight:700,cursor:"pointer"}}>Verrouiller</button>
        </div>
      </div>
      <div style={{background:th.card,border:"1px solid "+th.border,borderRadius:13,padding:"16px 18px"}}><div style={{fontWeight:700,fontSize:13,color:th.text,marginBottom:6}}>A propos</div><div style={{fontSize:12,color:th.muted,lineHeight:1.7}}>EmpManager Pro v6.0 - React 18 - Compatible Chrome Firefox Safari<br/>8 themes - CRUD complet - Listes editables - Matricules - PDF et Excel<br/>Theme actif : <strong style={{color:th.accent}}>{THEMES[thKey]?.name}</strong></div></div>
    </div>
  );
}

export default function App() {
  const [thKey,setThKey]=useState("midnight");
  const th=THEMES[thKey]||THEMES.midnight;
  const [emps,setEmps]=useState(INIT_EMPS);
  const [lists,setLists]=useState(DEFAULT_LISTS);
  const [tab,setTab]=useState("dashboard");
  const [locked,setLocked]=useState(false);
  const [collapsed,setCollapsed]=useState(false);
  const [mOpen,setMOpen]=useState(false);
  const [showAdd,setShowAdd]=useState(false);
  const [editEmp,setEditEmp]=useState(null);
  const [delEmp,setDelEmp]=useState(null);
  const [selEmp,setSelEmp]=useState(null);
  const [isMob,setIsMob]=useState(typeof window!=="undefined"?window.innerWidth<768:false);

  useEffect(()=>{const h=()=>setIsMob(window.innerWidth<768);window.addEventListener("resize",h);return()=>window.removeEventListener("resize",h);},[]);
  const saveEmp=useCallback(emp=>{setEmps(p=>p.some(e=>e.id===emp.id)?p.map(e=>e.id===emp.id?emp:e):[...p,emp]);},[]);
  const delEmpFn=useCallback(emp=>{setEmps(p=>p.filter(e=>e.id!==emp.id));setDelEmp(null);},[]);
  const updateLists=useCallback(updates=>{setLists(prev=>({...prev,...updates}));},[]);

  const NAV=[{id:"dashboard",label:"Tableau de bord"},{id:"employees",label:"Employes"},{id:"teams",label:"Equipes"},{id:"functions",label:"Fonctions"},{id:"lists",label:"Gestion listes"},null,{id:"settings",label:"Parametres"}];
  const currentLabel=(NAV.find(n=>n&&n.id===tab)||{}).label||"";
  const sw=isMob?0:collapsed?52:220;

  if(locked)return <LockScreen th={th} onUnlock={()=>setLocked(false)}/>;

  return (
    <div style={{display:"flex",height:"100vh",background:th.bg,color:th.text,overflow:"hidden",fontFamily:"'Segoe UI',system-ui,sans-serif"}}>
      <GStyle th={th}/>
      {isMob&&mOpen&&<div onClick={()=>setMOpen(false)} style={{position:"fixed",inset:0,zIndex:299,background:"rgba(0,0,0,.5)"}}/>}

      <div style={{width:isMob?220:sw,flexShrink:0,background:th.surf,borderRight:"1px solid "+th.border,display:"flex",flexDirection:"column",transition:"width .22s ease, transform .22s ease",overflow:"hidden",position:isMob?"fixed":"relative",left:0,top:0,bottom:0,transform:isMob?(mOpen?"translateX(0)":"translateX(-100%)"):"none",zIndex:isMob?300:1}}>
        <div style={{padding:"14px",display:"flex",alignItems:"center",gap:10,borderBottom:"1px solid "+th.border,height:56,flexShrink:0}}>
          <div style={{width:30,height:30,borderRadius:9,background:th.grad,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:900,color:"#fff",flexShrink:0}}>E</div>
          {(!collapsed||isMob)&&<span style={{fontWeight:800,fontSize:14,color:th.text,whiteSpace:"nowrap"}}>EmpManager Pro</span>}
          {isMob&&<button onClick={()=>setMOpen(false)} style={{marginLeft:"auto",background:"none",border:"none",color:th.muted,fontSize:18,cursor:"pointer"}}>X</button>}
        </div>
        <nav style={{flex:1,padding:"8px 0",overflowY:"auto"}}>
          {NAV.map((item,i)=>{
            if(!item)return <div key={i} style={{height:1,background:th.border,margin:"6px 10px"}}/>;
            const active=tab===item.id;
            return <div key={item.id} onClick={()=>{setTab(item.id);if(isMob)setMOpen(false);}} title={(!isMob&&collapsed)?item.label:""} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",margin:"1px 8px",borderRadius:10,cursor:"pointer",background:active?th.soft:"transparent",borderLeft:"3px solid "+(active?th.accent:"transparent"),transition:"all .13s"}} onMouseEnter={e=>{if(!active)e.currentTarget.style.background=th.card;}} onMouseLeave={e=>{if(!active)e.currentTarget.style.background="transparent";}}>
              <span style={{width:8,height:8,borderRadius:"50%",background:active?th.accent:th.muted+"55",flexShrink:0}}/>
              {(!collapsed||isMob)&&<span style={{fontSize:13,fontWeight:active?700:500,color:active?th.accent:th.muted,whiteSpace:"nowrap"}}>{item.label}</span>}
              {(!collapsed||isMob)&&active&&<span style={{marginLeft:"auto",width:5,height:5,borderRadius:"50%",background:th.accent,flexShrink:0}}/>}
            </div>;
          })}
        </nav>
        <div style={{borderTop:"1px solid "+th.border,padding:"6px"}}>
          <div onClick={()=>setLocked(true)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 12px",borderRadius:9,cursor:"pointer",transition:"all .13s"}} onMouseEnter={e=>e.currentTarget.style.background="#ff4d6d15"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
            <span style={{fontSize:12,color:"#ff4d6d",flexShrink:0}}>[ ]</span>
            {(!collapsed||isMob)&&<span style={{fontSize:12,fontWeight:600,color:th.muted,whiteSpace:"nowrap"}}>Verrouiller</span>}
          </div>
          {!isMob&&<div onClick={()=>setCollapsed(c=>!c)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 12px",borderRadius:9,cursor:"pointer",transition:"all .13s"}} onMouseEnter={e=>e.currentTarget.style.background=th.card} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
            <span style={{fontSize:12,color:th.muted,transform:collapsed?"rotate(180deg)":"none",transition:"transform .2s",display:"inline-block",width:18,textAlign:"center"}}>"&lt;&lt;"</span>
            {!collapsed&&<span style={{fontSize:12,fontWeight:600,color:th.muted}}>Reduire</span>}
          </div>}
        </div>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",minWidth:0}}>
        <div style={{height:56,borderBottom:"1px solid "+th.border,background:th.surf,display:"flex",alignItems:"center",padding:"0 16px 0 20px",gap:10,flexShrink:0}}>
          {isMob&&<button onClick={()=>setMOpen(true)} style={{background:"none",border:"1px solid "+th.border,borderRadius:8,width:34,height:34,color:th.muted,fontSize:16,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,cursor:"pointer"}}>=</button>}
          <div style={{fontWeight:700,fontSize:isMob?13:15,color:th.text,flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{currentLabel}</div>
          <div style={{fontSize:10,color:th.muted,background:th.card,border:"1px solid "+th.border,borderRadius:8,padding:"3px 10px",flexShrink:0,fontFamily:"monospace"}}>{emps.length} emp.</div>
          <button onClick={()=>exportCSV(emps)} style={{background:"none",border:"1px solid "+th.ok+"66",borderRadius:8,padding:"6px 10px",color:th.ok,fontSize:11,fontWeight:700,cursor:"pointer",flexShrink:0}}>CSV</button>
          <button onClick={()=>exportPDF(emps)} style={{background:"none",border:"1px solid "+th.err+"66",borderRadius:8,padding:"6px 10px",color:th.err,fontSize:11,fontWeight:700,cursor:"pointer",flexShrink:0}}>PDF</button>
          {!isMob&&<button onClick={()=>setShowAdd(true)} style={{background:th.grad,border:"none",borderRadius:9,padding:"7px 16px",color:"#fff",fontSize:12,fontWeight:700,cursor:"pointer",flexShrink:0,boxShadow:"0 3px 10px "+th.accent+"33"}}>+ Ajouter</button>}
          <button onClick={()=>setLocked(true)} style={{background:"none",border:"1px solid "+th.border,borderRadius:8,width:34,height:34,color:th.muted,fontSize:13,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,cursor:"pointer"}}>L</button>
        </div>
        <div style={{flex:1,overflowY:"auto",padding:isMob?"14px":"22px"}}>
          {tab==="dashboard"&&<Dashboard th={th} emps={emps}/>}
          {tab==="employees"&&<EmpTable th={th} emps={emps} lists={lists} onSel={setSelEmp} onEdit={e=>setEditEmp(e)} onDel={e=>setDelEmp(e)} onAdd={()=>setShowAdd(true)}/>}
          {tab==="teams"&&<TeamsView th={th} emps={emps} onEditEmp={e=>setEditEmp(e)} onDelEmp={e=>setDelEmp(e)}/>}
          {tab==="functions"&&<FunctionsView th={th} emps={emps}/>}
          {tab==="lists"&&<ListManager th={th} lists={lists} onUpdateLists={updateLists}/>}
          {tab==="settings"&&<SettingsView th={th} thKey={thKey} setThKey={setThKey} onLock={()=>setLocked(true)} emps={emps}/>}
        </div>
        {isMob&&<button onClick={()=>setShowAdd(true)} style={{position:"fixed",bottom:20,right:20,width:52,height:52,borderRadius:"50%",background:th.grad,border:"none",color:"#fff",fontSize:24,cursor:"pointer",zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 5px 18px "+th.accent+"55"}}>+</button>}
      </div>

      {(showAdd||editEmp)&&<EmpForm th={th} emps={emps} emp={editEmp} lists={lists} onClose={()=>{setShowAdd(false);setEditEmp(null);}} onSave={saveEmp} onUpdateLists={updateLists}/>}
      {delEmp&&<ConfirmDel th={th} title="Supprimer cet employe ?" desc={delEmp.name+" ("+delEmp.mat+") sera definitivement supprime."} onClose={()=>setDelEmp(null)} onOk={()=>delEmpFn(delEmp)}/>}
      {selEmp&&<Drawer th={th} emp={selEmp} emps={emps} onClose={()=>setSelEmp(null)} onEdit={e=>setEditEmp(e)} onDelete={e=>setDelEmp(e)}/>}
    </div>
  );
}
