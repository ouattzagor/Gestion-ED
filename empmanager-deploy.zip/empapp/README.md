# EmpManager Pro v6

Application professionnelle de gestion des employes.

## Lancer en local

```bash
npm install
npm start
```

## Deployer sur Netlify (le plus simple)

### Option 1 - Sans GitHub (drag and drop)
1. `npm install`
2. `npm run build`
3. Aller sur https://app.netlify.com
4. Glisser le dossier `build/` sur la page
5. Votre site est en ligne !

### Option 2 - Avec GitHub (recommande)
1. Creer un compte GitHub : https://github.com
2. Nouveau repository : cliquer "New" > nommer > "Create repository"
3. Dans ce dossier, executer :
   ```
   git init
   git add .
   git commit -m "EmpManager Pro"
   git remote add origin https://github.com/VOTRE-NOM/empmanager.git
   git push -u origin main
   ```
4. Sur Netlify : "Add new site" > "Import from Git" > GitHub
5. Build command : `npm run build`
6. Publish directory : `build`
7. "Deploy site" - votre URL sera prete en 2 minutes !

## Deployer sur Vercel

```bash
npx vercel --prod
```

## Fonctionnalites
- Tableau de bord avec KPIs
- Gestion complete des employes (ajout, modification, suppression)
- Matricules automatiques
- Equipes avec hierarchie automatique
- Fonctions et niveaux
- Gestion des listes (equipes, postes, niveaux, contrats, departements)
- 8 themes visuels
- Export PDF et Excel/CSV
- Verrouillage PIN (code : 1234)
- Responsive mobile + desktop
